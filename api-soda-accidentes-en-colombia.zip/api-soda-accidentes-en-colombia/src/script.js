fetch('https://www.datos.gov.co/resource/yb9r-2dsi.json?$limit=50000')
.then(response => response.json())
.then(data => {

    let tipos = {};

    data.forEach(item => {

        let tipo = item.clase_accidente || "Sin dato";

        tipos[tipo] = (tipos[tipo] || 0) + 1;

    });

    const labels = Object.keys(tipos);
    const values = Object.values(tipos);

    var chart = [{
        x: labels,
        y: values,
        type: 'bar',

        marker: {
            color: '#3f51b5'
        },

        text: values,
        textposition: 'none',

        hovertemplate:
        '<b>%{x}</b><br>Total: %{y}<extra></extra>'
    }];

    var layout = {
        title: 'Cantidad de Accidentes por Tipo',
        paper_bgcolor: '#ffffff',
        plot_bgcolor: '#ffffff',

        xaxis: {
            tickangle: 90
        },

        yaxis: {
            gridcolor: '#dddddd'
        },

        margin: {
            t: 60,
            b: 150
        }
    };

    Plotly.newPlot('myDiv', chart, layout, {
        responsive: true
    });

})
.catch(error => console.log(error));