# Api Rick y Morty

A Pen created on CodePen.

Original URL: [https://codepen.io/Cantillo-Nadin/pen/gbwEpXO](https://codepen.io/Cantillo-Nadin/pen/gbwEpXO).

