const Rick = document.getElementById('Rick');

const fetchCharacters = async () => {
    let allCharacters = [];
    let url = 'https://rickandmortyapi.com/api/character';

    try {
        while (url) {
            const res = await fetch(url);
            const data = await res.json();

            allCharacters = allCharacters.concat(data.results);
            url = data.info.next;
        }

        displayCharacters(allCharacters);

    } catch (error) {
        console.error("Error al cargar la API:", error);
    }
};

const displayCharacters = (characters) => {
    const html = characters.map((char) => `
        <li class="card">
            <img class="card-image" src="${char.image}" />
            <h2 class="card-title">${char.id}. ${char.name}</h2>
            <p class="card-subtitle">Status: ${char.status}</p>
            <p class="card-subtitle">Species: ${char.species}</p>
        </li>
    `).join('');

    Rick.innerHTML = html;
};

fetchCharacters();